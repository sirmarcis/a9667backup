LAB 1: GETTING STARTED


NAME:  Anders Maraviglia



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to in the first lecture & first
lab (classmates, graduate TAs, undergraduate programming mentors, ALAC
tutors, upperclassmen, students/instructor via LMS, etc.), and all of
the resources (books, online reference material, etc.) you consulted
in completing this assignment.


None


Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.













