HOMEWORK 1: ASCII FONT ART


NAME:  Anders Maraviglia


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassment, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

http://www.cplusplus.com/

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  4-5



EXTRA CREDIT: KERNING 
Describe your implementation & paste in interesting example output
with & without kerning.  Please be concise!



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

I hope its ok that I used a hash table like thing...

