HOMEWORK 5: LINKED PLAYING CARDS


NAME:  Anders Maraviglia


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

none

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  15-20



DESCRIPTION OF RANDOMNESS IMPLEMENTATION AND ANALYSIS OF RANDOMNESS
FOR EXTRA CREDIT:



MISC. COMMENTS TO GRADER:  
Optional, please be concise!


