HOMEWORK 6: RICOCHET ROBOT CONTEST


NAME:  Anders Maraviglia



COLLABORATORS AND OTHER RESOURCES:
none



DESCRIPTION OF PERFORMANCE IMPROVEMENTS/OPTIMIZATIONS:
I cleaned up the junk I didn't have time to get rid of by the regular deadline.  I pass everything I can by refrence
and everything else is either so small as to not matter much, or necessary for the algorithm.



DESCRIBE INTERESTING NEW PUZZLES YOU CREATED:
I created none, sorry.



SUMMARY OF YOUR PERFORMANCE ON ALL PUZZLES:
I would like to think I made a high preforming algorithm, and recursion is naturally a little slower than 
an iterative approach, but the latter would be so complex that it would take at least another two to three weeks to write.


